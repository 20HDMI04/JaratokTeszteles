using JaratKezeloProject;

namespace TestJaratKezeloProject
{
    public class Tests
    {
        JaratKezelo jaratKezelo;
        [SetUp]
        public void Setup()
        {
            jaratKezelo = new JaratKezelo();
        }

        [Test]
        public void UjJarat_UresJarat_ArgumentExceptiontDob()
        {
            Assert.Throws<ArgumentException>(() => jaratKezelo.UjJarat("", "Budapest", "London", DateTime.Now));
        }

        [Test]
        public void UjJarat_NullJarat_ArgumentNullExceptiontDob()
        {
            Assert.Throws<ArgumentNullException>(() => jaratKezelo.UjJarat(null, "Budapest", "London", DateTime.Now));
        }

        [Test]
        public void UjJarat_UresRepterHonnan_ArgumentExceptiontDob()
        {
            Assert.Throws<ArgumentException>(() => jaratKezelo.UjJarat("123", "", "London", DateTime.Now));
        }

        [Test]
        public void UjJarat_NullRepterHonnan_ArgumentNullExceptiontDob()
        {
            Assert.Throws<ArgumentNullException>(() => jaratKezelo.UjJarat("123", null, "London", DateTime.Now));
        }

        [Test]
        public void UjJarat_UresRepterHova_ArgumentExceptiontDob()
        {
            Assert.Throws<ArgumentException>(() => jaratKezelo.UjJarat("123", "Budapest", "", DateTime.Now));
        }

        [Test]
        public void UjJarat_NullRepterHova_ArgumentNullExceptiontDob()
        {
            Assert.Throws<ArgumentNullException>(() => jaratKezelo.UjJarat("123", "Budapest", null, DateTime.Now));
        }

        [Test]
        public void UjJarat_MarLetezoJarat_ArgumentExceptiontDob()
        {
            jaratKezelo.UjJarat("123", "Budapest", "London", DateTime.Now);
            Assert.Throws<ArgumentException>(() => jaratKezelo.UjJarat("123", "Budapest", "London", DateTime.Now));
        }

        [Test]
        public void Keses_UresJaratSzam_ArgumentExceptiontDob()
        {
            Assert.Throws<ArgumentException>(() => jaratKezelo.Keses("", 10));
        }

        [Test]
        public void Keses_NullJaratSzam_ArgumentNullExceptiontDob()
        {
            Assert.Throws<ArgumentNullException>(() => jaratKezelo.Keses(null, 10));
        }

        [Test]
        public void Keses_NemLetezoJaratSzam_ArgumentExceptiontDob()
        {
            Assert.Throws<ArgumentException>(() => jaratKezelo.Keses("123", 10));
        }

        [Test]
        public void Keses_NegativKeses_NegativKesesExceptiontDob()
        {
            jaratKezelo.UjJarat("123", "Budapest", "London", DateTime.Now);
            Assert.Throws<NegativKesesException>(() => jaratKezelo.Keses("123", -10));
        }

        [Test]
        public void Keses_NemNegativKeses_KesesFrissul()
        {
            jaratKezelo.UjJarat("123", "Budapest", "London", DateTime.Now);
            jaratKezelo.Keses("123", 10);
            Assert.AreEqual(10, jaratKezelo.jaratok[0].keses);
        }


        }
    }