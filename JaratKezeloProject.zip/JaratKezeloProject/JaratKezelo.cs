﻿namespace JaratKezeloProject
{
    public class JaratKezelo
    {
        public class Jarat
        {
            public string jaratSzam;
            public string repterHonnan;
            public string repterHova;
            public DateTime indulas;
            public int keses;

            public override string ToString()
            {
                return jaratSzam + "," + repterHonnan + "," + repterHova + "," + indulas + "," + keses;
            }
        }

        public List<Jarat> jaratok = new List<Jarat>();

        public void UjJarat(string jaratSzam, string repterHonnan, string repterHova, DateTime indulas)
        {
            if (jaratSzam == "") throw new ArgumentException("A járat szám nem lehet üres!");
            if (jaratSzam == null) throw new ArgumentNullException("A járat szám nem lehet null!");
            if (repterHonnan == "") throw new ArgumentException("A reptér honnan nem lehet üres!");
            if (repterHonnan == null) throw new ArgumentNullException("A reptér honnan nem lehet null!");
            if (repterHova == "") throw new ArgumentException("A reptér hova nem lehet üres!");
            if (repterHova == null) throw new ArgumentNullException("A reptér hova nem lehet null!");

            Jarat j = new Jarat();
            j.jaratSzam = jaratSzam;
            j.repterHonnan = repterHonnan;
            j.repterHova = repterHova;
            j.indulas = indulas;
            j.keses = 0;

            if (jaratok.Contains(j))
            {
                throw new ArgumentException("Már létezik ilyen járat!");
            }

            jaratok.Add(j);
        }

        public void Keses(string jaratSzam, int keses)
        {
            if (jaratSzam == "") throw new ArgumentException("A járat szám nem lehet üres!");
            if (jaratSzam == null) throw new ArgumentNullException("A járat szám nem lehet null!");
            if (!jaratok.Any(e => e.jaratSzam == jaratSzam)) throw new ArgumentException();
            if (keses == 0) throw new ArgumentException();

            foreach (var j in jaratok)
            {
                if (j.jaratSzam == jaratSzam)
                {
                    j.keses += keses;
                    if (j.keses < 0)
                    {
                        throw new NegativKesesException();
                    }
                }
            }
        }

        public DateTime MikorIndul(string jaratSzam)
        {
            if (jaratSzam == "") throw new ArgumentException("A járat szám nem lehet üres!");
            if (jaratSzam == null) throw new ArgumentNullException("A járat szám nem lehet null!");
            foreach (var j in jaratok)
            {
                if (j.jaratSzam == jaratSzam)
                {
                    return j.indulas.AddMinutes(j.keses);
                }
            }
            throw new ArgumentException("Nincs ilyen járat!");
        }

        public List<string> JaratokRepuloterrol(string repter)
        {
            if (repter == "") throw new ArgumentException("A reptér nem lehet üres!");
            if (repter == null) throw new ArgumentNullException("A reptér nem lehet null!");
            if (!jaratok.Any(e => e.repterHonnan == repter)) throw new ArgumentException("Nincs ilyen reptér!");
            List<string> jaratokRepuloterrol = new List<string>();
            foreach (var j in jaratok)
            {
                if (j.repterHonnan == repter)
                {
                    jaratokRepuloterrol.Add(j.jaratSzam);
                }
            }
            return jaratokRepuloterrol;
        }

    }
}
