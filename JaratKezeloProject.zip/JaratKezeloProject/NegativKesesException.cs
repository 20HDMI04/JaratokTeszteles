﻿
namespace JaratKezeloProject
{
    [Serializable]
    public class NegativKesesException : Exception
    {
        public NegativKesesException()
        {
            throw new Exception("Negatív késés nem hozható létre!");
        }
    }
}